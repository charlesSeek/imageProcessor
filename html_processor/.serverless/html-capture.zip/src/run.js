const launch = require('@serverless-chrome/lambda')

const handler = require('./p87l03er9yg___run.js')
const options = {"functions":["run"],"flags":[]}

module.exports.default = function ensureHeadlessChrome (
  event,
  context,
  callback
) {
  return (typeof launch === 'function' ? launch : launch.default)(options)
    .then(instance =>
      handler.default(event, context, callback, instance))
    .catch((error) => {
      console.error(
        'Error occured in serverless-plugin-chrome wrapper when trying to ' +
          'ensure Chrome for default() handler.',
        options,
        error
      )

      callback(error)
    })
}