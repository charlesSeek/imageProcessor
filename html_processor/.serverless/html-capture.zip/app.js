var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const AWS = require('aws-sdk');
const path = require('path');
const s3 = new AWS.S3();
const sqs = new AWS.SQS({ region: 'us-east-1' });
const fs = require('fs');
const Chromeless = require('chromeless').default;
const helpers = {
    cleanup: function (filepath) {
        if (fs.existsSync(filepath)) {
            console.log("Removing", filepath);
            fs.unlinkSync(filepath);
        }
    },
    sqs: function (queueUrl, message) {
        return new Promise(function (resolve) {
            const params = {
                MessageBody: JSON.stringify(message),
                QueueUrl: queueUrl
            };
            sqs.sendMessage(params, function (err, data) {
                if (err) {
                    console.log('error:', "Fail Send Message" + err);
                }
                resolve();
            });
        });
    }
};
const generate = function (job) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("Inside generate 01");
        let chromeless = new Chromeless({
            debug: true,
            remote: {
                endpointUrl: 'https://2779gb4ur5.execute-api.us-east-1.amazonaws.com/dev/',
                apiKey: 'bjg5CP2aRL156AETLUlQk2qcVPxprlspgLvgoBHf'
            }
        });
        console.log("Inside generate 001");
        let screenshot = yield chromeless
            .goto(job.url)
            .screenshot();
        console.log("Inside generate 02", screenshot);
        yield chromeless.end();
        return screenshot;
    });
};
const uploadImage = function (imagePath, bucket, baseKey) {
    return new Promise(function (resolve) {
        let imageFilename = path.basename(imagePath);
        let baseFilename = path.basename(baseKey);
        let uploadKey = baseKey.replace(baseFilename, imageFilename);
        s3.putObject({
            Bucket: bucket,
            Key: uploadKey,
            Body: fs.readFileSync(imagePath),
            ACL: 'public-read',
            ContentDisposition: 'attachment'
        }, function (err, data) {
            if (err) {
                console.log(err);
                resolve(null);
            }
            resolve(uploadKey);
        });
    });
};
exports.handler = function (event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            for (let i = 0; i < event.Records.length; i++) {
                let record = event.Records[i];
                const job = JSON.parse(record.Sns.Message);
                console.log("Processing HTML Screenshot...", job);
                let screenshot = yield generate(job);
                console.log("Screenshot", screenshot);
                let key = yield uploadImage(screenshot, job.bucket, job.key);
                helpers.cleanup(screenshot);
                job.success = true;
                yield helpers.sqs(job.queue, job);
            }
            context.done();
        }
        catch (err) {
            console.log(err);
        }
    });
};
//# sourceMappingURL=app.js.map